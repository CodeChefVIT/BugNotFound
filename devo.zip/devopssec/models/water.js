let mongoose = require('mongoose');
//let shortid = require("shortid");

let water = new mongoose.Schema({
    value: {type: String, default: undefined, require: true},
    time: {type: Date, default: Date.now},
    status: {type: String, default: "LOW"}
});

module.exports = mongoose.model('waters',water);