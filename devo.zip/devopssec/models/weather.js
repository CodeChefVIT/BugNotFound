let mongoose = require('mongoose');

let idea = new mongoose.Schema({
    name: {type: String, default: undefined, require: true},
    time: {type: Date, default: Date.now},
});

module.exports = mongoose.model('ideas',idea);