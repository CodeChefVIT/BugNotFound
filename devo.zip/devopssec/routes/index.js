var express = require('express');
var router = express.Router();
var Water = require("../models/water");
var Soil = require("../models/soil");
var Weather = require("../models/weather");

var response = {
    status: "OK", 
    list: [], 
    data: ""
};

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//soil data submission
router.post('/data/collection/soil', (req,res)=>{
    const data = {value: req.body.soil}
    Soil.create(data, (err, created)=>{
        if (err){
            response.status = "NOT";
            throw err;
        }
        res.json(response);
    });
});

//water data submission
router.post('/data/collection/water', (req,res)=>{
    const data = {value: req.body.soil}
    Water.create(data, (err, created)=>{
        if (err){
            response.status = "NOT";
            throw err;
        }
        res.json(response);
    });
});

module.exports = router;

